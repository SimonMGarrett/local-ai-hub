import type { ReactNode } from "react";
export function SiteHeader({ prefix, kind }: { prefix: string; kind: string }) {
  return (
    <header className="site-header">
      <nav aria-label="Main navigation">
        <a className="brand" href={`${prefix}index.html`}>
          MOSAIC
        </a>
        <a href={`${prefix}index.html#how`}>How it works</a>
        <a
          href={`${prefix}insights/index.html`}
          aria-current={
            kind === "index"
              ? "page"
              : kind === "article"
                ? "location"
                : undefined
          }
        >
          Insights
        </a>
      </nav>
    </header>
  );
}
export function ContentContainer({
  children,
  home = false,
}: {
  children: ReactNode;
  home?: boolean;
}) {
  return (
    <main className={home ? "home" : undefined} id="main" tabIndex={-1}>
      {children}
    </main>
  );
}
export function SiteLayout({
  children,
  prefix,
  kind,
  provenance,
}: {
  children: ReactNode;
  prefix: string;
  kind: string;
  provenance?: ReactNode;
}) {
  return (
    <>
      <a className="skip" href="#main">
        Skip to content
      </a>
      <div className="notice">
        Review draft v0.6 · Design and accuracy review pending · No participant
        results
      </div>
      <SiteHeader prefix={prefix} kind={kind} />
      <ContentContainer home={kind === "home"}>{children}</ContentContainer>
      <footer className="site-footer">
        {provenance || <>Insights source captured 28 September 2026.</>}
        <p>
          <a href={`${prefix}insights/index.html`}>All insights</a> ·{" "}
          <a href={`${prefix}index.html`}>MOSAIC home</a>
        </p>
      </footer>
    </>
  );
}
