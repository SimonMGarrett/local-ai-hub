// Existing article API retained; no nested controls or client script required.
import type { ComponentProps } from "react";
import { ActionLink } from "./ActionLink";
export function PrimaryButton(
  props: ComponentProps<typeof ActionLink> & { umamiEvent?: string },
) {
  return <ActionLink {...props} />;
}
