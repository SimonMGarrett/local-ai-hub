import { Fragment } from "react";
import { forms, records } from "../content/home";
export function FormGroup() {
  return (
    <div className="forms">
      {forms.map((f) => (
        <article key={f.letter}>
          <span className="letter" aria-hidden="true">
            {f.letter}
          </span>
          <h3>{f.title}</h3>
          <p>{f.body}</p>
        </article>
      ))}
    </div>
  );
}
export function RecordGroup() {
  return (
    <div className="record">
      {records.map((r) => (
        <div key={r.title}>
          <span className="symbol" aria-hidden="true">
            {r.symbol}
          </span>
          <h3>{r.title}</h3>
          <p>
            {r.lines.map((line, i) => (
              <Fragment key={line}>
                {i > 0 && <br />}
                {line}
              </Fragment>
            ))}
          </p>
        </div>
      ))}
    </div>
  );
}
