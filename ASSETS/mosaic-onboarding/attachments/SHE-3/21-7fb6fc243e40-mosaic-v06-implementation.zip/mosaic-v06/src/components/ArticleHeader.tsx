import { SectionHeading } from "./SectionHeading";
import type { ComponentProps } from "react";
export function ArticleHeader(props: ComponentProps<typeof SectionHeading>) {
  return (
    <div className="article-header">
      <a className="article-back" href="../index.html">
        ← All insights
      </a>
      <SectionHeading {...props} />
    </div>
  );
}
