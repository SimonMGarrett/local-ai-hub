import type { ReactNode } from "react";
export function SectionHeading({
  eyebrow,
  title,
  children,
  level = "h2",
}: {
  eyebrow?: string;
  title: string;
  children?: ReactNode;
  level?: "h1" | "h2";
}) {
  const Heading = level;
  return (
    <div className="section-heading">
      {eyebrow && <p className="eyebrow">{eyebrow}</p>}
      <Heading>{title}</Heading>
      {children && <div className="section-summary">{children}</div>}
    </div>
  );
}
