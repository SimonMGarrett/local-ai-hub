type Props = {
  title: string;
  summary: string;
  topic: string;
  time: string;
  path: string;
  image: string;
  imageAlt: string;
};
export function InsightCard({
  title,
  summary,
  topic,
  time,
  path,
  image,
  imageAlt,
}: Props) {
  return (
    <a
      aria-label={`Read article: ${title}`}
      className="insight-card"
      href={path}
    >
      <article>
        <img
          alt={imageAlt}
          decoding="async"
          height="360"
          loading="lazy"
          src={image}
          width="640"
        />
        <div className="card-content">
          <div className="card-meta">
            <span>{topic}</span>
            <span aria-hidden="true">/</span>
            <span>{time}</span>
          </div>
          <h2>{title}</h2>
          <p>{summary}</p>
          <span aria-hidden="true" className="card-action">
            Read article
          </span>
        </div>
      </article>
    </a>
  );
}
