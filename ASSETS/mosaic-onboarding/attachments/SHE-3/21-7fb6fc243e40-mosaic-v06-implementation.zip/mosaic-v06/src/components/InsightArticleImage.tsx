type Props = {
  src: string;
  alt: string;
  photographer?: string;
  photoUrl?: string;
};
export function InsightArticleImage({
  src,
  alt,
  photographer,
  photoUrl,
}: Props) {
  return (
    <figure className="article-image">
      <img alt={alt} decoding="async" height="900" src={src} width="1600" />
      {photographer && photoUrl && (
        <figcaption>
          Photo by{" "}
          <a href={photoUrl} rel="noreferrer" target="_blank">
            {photographer} on Unsplash
          </a>
        </figcaption>
      )}
    </figure>
  );
}
