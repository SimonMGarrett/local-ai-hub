import type { ReactNode } from "react";
export function ActionLink({
  to,
  children,
  className = "",
}: {
  to: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <a
      className={`action-link ${className}`}
      href={to === "/contact" ? "https://groundstoact.com/contact" : to}
    >
      {children}
    </a>
  );
}
