import { FormGroup, RecordGroup } from "../components/ReasoningGroups";
import { ActionLink } from "../components/ActionLink";
export function HomePage() {
  return (
    <>
      <p className="eyebrow">Decision framework</p>
      <h1>Make strong decisions from fragmented evidence</h1>
      <p>
        MOSAIC helps you make the most reasoned and defensible choice available
        when evidence is incomplete, uncertain, scattered, or open to more than
        one interpretation.
      </p>
      <ActionLink to="#start">Start with your decision →</ActionLink>
      <h2 id="what">What is MOSAIC?</h2>
      <p>
        MOSAIC is a framework for people making weighty decisions with
        incomplete, scattered or conflicting information. Use it to work towards
        the best-supported choice you can make with the information you have,
        and keep a reasoned audit trail of how you reached it. You remain
        responsible for the decision.
      </p>
      <p>
        <strong>Who is it for?</strong> People facing choices with significant
        consequences, who want to examine their reasons carefully and be able to
        explain them later. The starting point is a decision that matters to
        you.
      </p>
      <p>
        <strong>What do you produce?</strong> A reasoned audit trail: what you
        knew at the time, where it came from, assumptions you made, options you
        considered, why you chose, what remained uncertain and what would make
        you reconsider. If things go wrong, this record lets you revisit the
        reasoning in its original context. It does not guarantee a good outcome.
      </p>
      <p className="actions">
        <ActionLink to="#start">Start with your decision →</ActionLink>
        <a href="#how">Explore the six forms</a>
      </p>
      <h2 id="how">How it works</h2>
      <p>
        Use six forms of reasoning, revisiting them as gaps emerge. They are not
        a fixed one-way sequence.
      </p>
      <section aria-label="Six connected forms of reasoning">
        <div className="hub">
          ONE DECISION · SIX CONNECTED FORMS OF REASONING
        </div>
        <FormGroup />
        <p className="return">
          ↶ Revisit any form when a gap or new evidence changes the reasoning.
        </p>
      </section>
      <section aria-labelledby="record">
        <h2 id="record">Keep the reasons with the choice.</h2>
        <p>A record you can revisit when the outcome is known.</p>
        <RecordGroup />
        <p className="caption">
          An editorial view of a decision record—not extra MOSAIC stages or a
          prescribed template.
        </p>
      </section>
      <h2 id="start">Start a decision</h2>
      <p>
        Write: “By [date], [owner] needs to choose between [options], to achieve
        [outcome], within [constraints].” Then list what you know, its sources
        and which uncertainty could change the choice. Use the six forms to
        examine it; retain reasons and review conditions with the choice. This
        prompt is an editorial aid, not another MOSAIC stage or a prescribed
        record format.
      </p>
      <h2 id="limits">About / FAQ</h2>
      <p>
        <strong>Does MOSAIC decide for me?</strong> No. Human judgement and
        responsibility remain.
      </p>
      <p>
        <strong>Does it guarantee a good outcome?</strong> No. Preserve what was
        known at decision time and learn from later outcomes; a reasoned choice
        can still have an adverse outcome.
      </p>
      <p>
        <strong>Is it a score?</strong> No canonical numerical scoring method is
        established here. Existing demonstration counts and weights are teaching
        devices.
      </p>
      <p>
        <strong>Why is Analysis also outside MOSAIC?</strong> External
        analytical work supplies material. Internal Analysis examines structured
        evidence for this decision. Operational systems implement the chosen
        action.
      </p>
      <p>
        <strong>How established is it?</strong> The public framework is
        developing. This draft explains a founder-confirmed website baseline,
        not measured effectiveness.
      </p>
    </>
  );
}
export function HomeProvenance() {
  return (
    <>
      Editorial prototype based on the founder-confirmed website baseline, 27
      September 2026. No information is collected or sent by this page.
      <details>
        <summary>Reviewer provenance (exclude from participant copy)</summary>
        <p>
          Core reference v0.2: SHE-2, document core-reference, revision
          3995e839-f6b7-40ef-93fd-ec2de31c9b32. Oracle verdict: SHE-3, document
          oracle-accuracy-review, revision d7fba4d2-71f9-4848-9baa-101926fa7418,
          covers v0.1 (historical). Focused v0.3 accuracy review: SHE-3,
          document oracle-v03-review, revision
          15ee71e9-6bb8-424c-a836-1df920789c8d; passed. That verdict covers
          v0.3. v0.4 restores the exact hero wording supplied by the founder on
          28 September 2026, comment 1525e4b7-2654-48bf-bed1-51330c709e47.
          Focused v0.4 accuracy review passed in full page context: SHE-3,
          document oracle-v04-review, revision
          1bc99c7b-94f3-4227-9e60-2777032dfbda. Frontend verification: document
          v04-frontend-verification. Design verdict and acceptance criteria:
          document v04-design-verdict, revision
          35c21b09-dbbd-4607-a4ec-29b0bfe2a493. Protocol exposure metadata:
          v0.4, document comprehension-test, revision
          eede00b4-9553-43f7-86de-5d62c4415290.
        </p>
        <p>
          Founder response ff01d42c-a1f2-41e5-ba11-aedb72f31b5e directs
          consequential-decision positioning, explanatory visuals and omission
          of the provisional glimpse. Six-form visual: C1–C7. Audit-trail
          grouping: C2/C3/C6/C12 and editorial record flexibility I1. These
          visuals are editorial explanations, not new stages. Audience and
          best-supported-choice wording expresses intended use, not measured
          effectiveness or guaranteed optimality. Identifiers are recoverable in
          Paperclip. External navigation is disallowed during assessment.
        </p>
      </details>
    </>
  );
}
