import { InsightCard } from "../components/InsightCard";
import { PageMeta } from "../components/PageMeta";
import { SectionHeading } from "../components/SectionHeading";
import { insightCards } from "../content/insights";

export default function InsightsPage() {
  return (
    <>
      <PageMeta
        title="Insights"
        description="Notes on evidence, provenance, uncertainty, analysis, and defensible decision-making."
        path="/insights"
      />
      <section className="insights-page">
        <SectionHeading
          eyebrow="Insights"
          title="Notes on evidence, uncertainty, and defensible decision-making."
          level="h1"
        >
          Proposed articles for the first release. They explore the boundary
          between analysis, decision-making, and action.
        </SectionHeading>
        <div className="insights-grid">
          {insightCards.map((card) => (
            <InsightCard key={card.title} {...card} />
          ))}
        </div>
      </section>
    </>
  );
}
