import { InsightArticleImage } from "../../components/InsightArticleImage";
import { PageMeta } from "../../components/PageMeta";
import { PrimaryButton } from "../../components/PrimaryButton";
import { ArticleHeader as SectionHeading } from "../../components/ArticleHeader";

export default function MoreDataPage() {
  return (
    <>
      <PageMeta
        title="Why more data does not automatically produce a better decision"
        description="More information only improves a decision when it is relevant, interpretable, and connected to a clear choice."
        path="/insights/more-data"
      />
      <section className="article-page">
        <SectionHeading
          eyebrow="Decision quality"
          title="Why more data does not automatically produce a better decision"
          level="h1"
        >
          Evidence needs structure, relevance, and interpretation before it can
          support action.
        </SectionHeading>

        <InsightArticleImage
          alt="Hands reviewing printed financial charts beside a calculator and phone"
          photographer="Jakub Żerdzicki"
          photoUrl="https://unsplash.com/photos/office-desk-with-smartphone-and-financial-charts-heiYgqp0Tsk"
          src="/insights/more-data.jpg"
        />

        <article className="insight-article">
          <p>
            It is easy to assume that a better decision begins with collecting{" "}
            <strong>more data</strong>. Sometimes it does: a missing
            measurement, a local perspective, or a more current figure can
            materially change what is sensible to do. But data has no automatic
            route to better judgement. A larger pile of reports, dashboards, and
            model outputs can just as easily make the important question harder
            to see.
          </p>
          <p className="space-before">
            The first issue is <strong>relevance</strong>. Every decision has a
            purpose, a timescale, people who will be affected, and practical
            constraints. Information is useful when it helps make one of those
            things clearer. It is less useful when it is merely available,
            impressive, or easy to count. A team deciding whether to intervene
            next week needs different evidence from a team setting a three-year
            direction. Treating both as a generic request for “more data” blurs
            that distinction.
          </p>
          <p className="space-before">
            Then there is <strong>structure</strong>. Sources often describe
            different populations, periods, definitions, and levels of
            certainty. Without keeping those differences visible, comparisons
            become accidental. A precise-looking number may be based on a
            partial sample; a qualitative account may explain a change that a
            dashboard cannot. Neither should be discarded simply because the
            other is easier to aggregate. The work is to understand what each
            item can support, where it came from, and where its limits lie.
          </p>
          <p className="space-before">
            <strong>
              Interpretation is the bridge between evidence and action.
            </strong>{" "}
            It asks what the available material means for the choice at hand,
            what alternatives remain plausible, and which assumptions are
            carrying the most weight. That does not mean waiting for perfect
            certainty. Decisions often need to be made with incomplete
            information. The aim is to be explicit about the uncertainty, rather
            than allowing it to disappear beneath a larger volume of data.
          </p>
          <p className="space-before">
            A practical question is:{" "}
            <strong>
              what information, if we had it, would actually change our choice?
            </strong>{" "}
            This can reveal whether an investigation is focused or simply
            expanding. It can also show when the next useful step is not another
            analysis, but a conversation, a small test, or a decision with a
            clear condition for review.
          </p>
          <p className="space-before">
            MOSAIC is designed to make this reasoning visible: to connect
            observations to their context, separate evidence from
            interpretation, and preserve the rationale for a choice. The right
            approach depends on the decision, the organisation, and the
            consequences of being wrong. If you are working through a data-rich
            decision and want help finding the evidence that matters, contact
            Simon to discuss it.
          </p>
          <div className="space-before">
            <PrimaryButton to="/contact">Contact Simon</PrimaryButton>
          </div>
        </article>
      </section>
    </>
  );
}
