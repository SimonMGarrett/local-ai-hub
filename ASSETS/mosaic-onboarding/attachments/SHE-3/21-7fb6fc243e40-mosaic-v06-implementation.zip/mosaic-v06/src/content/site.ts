export const siteConfig = {
  name: "MOSAIC",
  authorName: "Simon G",
  canonicalUrl: "https://groundstoact.com",
  contactEmail: "replace-me@example.com",
  socialLinks: {
    linkedIn: "#",
  },
};

export const workedExampleDisclaimer =
  "These worked examples are educational demonstrations. They simplify real decision problems in order to show particular reasoning patterns. They do not provide professional advice or replace domain expertise.";
