export const forms = [
  {
    letter: "M",
    title: "Meaning",
    body: "What decision are we making? Name the owner, options, desired outcome, deadline and constraints. Produce a clear decision statement.",
  },
  {
    letter: "O",
    title: "Observations",
    body: "What material do we have? Separate observations, reports, inferences and assumptions. Record origins and gaps.",
  },
  {
    letter: "S",
    title: "Structure",
    body: "How does it connect? Link sources to claims and options. Preserve contradictions and shared origins.",
  },
  {
    letter: "A",
    title: "Analysis",
    body: "What does the evidence support? Examine competing explanations and assumptions. Record findings and limits.",
  },
  {
    letter: "I",
    title: "Interpretation",
    body: "What does that mean for our options? Consider consequences, risks and trade-offs, including uncertainty that could change the choice.",
  },
  {
    letter: "C",
    title: "Choice",
    body: "What will we do, and why? Commit to the course best supported in context, and record the reasons, rejected alternatives, uncertainty and review conditions. Targeted inquiry may be warranted when its value justifies its cost.",
  },
];
export const records = [
  {
    symbol: "◇",
    title: "What you had",
    lines: ["Information", "Origins", "Assumptions"],
  },
  {
    symbol: "⇄",
    title: "What you considered",
    lines: ["Options", "Consequences", "Uncertainty"],
  },
  {
    symbol: "◎",
    title: "What you chose",
    lines: ["Choice", "Reasons", "Review conditions"],
  },
];
