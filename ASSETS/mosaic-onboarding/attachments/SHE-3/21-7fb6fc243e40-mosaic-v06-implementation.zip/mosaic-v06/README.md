# MOSAIC v0.6 implementation draft

Open `site/index.html` directly after extraction. All eight pages, CSS and six original images are local. No server, build, JavaScript or network connection is required to read the draft. Existing external photo-credit/contact links remain external; no messages are sent automatically.

Sources: shared React components in `src/components`, page copy in `src/pages`, six-form/record content in `src/content/home.ts`, index content in `src/content/insights.ts`, and one token-based stylesheet in `src/styles/index.css`. `npm install` then `npm run build` recreates the static site. Dependency versions match those used for this build; a fresh dependency installation was not exercised. The provided build used read-only access to the existing source repository's installed dependencies. The dependency symlink is excluded from the archive.

`verify.cjs` and `supplemental.cjs` record the focused browser checks. They need Playwright and the local Edge executable path configured in those files, plus the sibling v0.5 package for parity comparisons. The rendered artifact itself is portable; verification harness paths are environment-specific. `verification/results.json` and `supplemental.json` contain results. Screenshots are in the separate renders archive.

The only substantive copy change from v0.5 is the founder-approved Confidence clarification: “Its stages help distinguish” becomes “Its six forms of reasoning, which can be revisited as needed, help distinguish”. Homepage content, article paragraphs, headers, credits, image bytes/alt text and contact destinations were compared. Navigation, review-version labels and design changed. Prior source hashes are retained in `source-manifest.json`; new site/source hashes are in `output-manifest.json`.

Design specification: `design-theme.md`, Paperclip design-theme revision 9df2ba9c-bc1e-4994-b219-e4ba2ecaba59. Written brief: v06-design-brief revision 12a9c4ba-d467-4f4f-84fa-7dd7aa8209a2. Framework accuracy remains for The Oracle; article commentary is not an approved baseline expansion. The homepage disclosure preserves historical review identifiers, not a v0.6 approval. v0.4 participant exposure remains frozen.

No production publication or participant testing. Native browser zoom, screen-reader output, other rendering engines and comprehensive accessibility remain unverified. Reflow at half desktop CSS width and 200% text enlargement were exercised; these are not native browser zoom checks.
