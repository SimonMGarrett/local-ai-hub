import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";
import { createHash } from "node:crypto";
const require = createRequire(import.meta.url);
const { buildSync } = require("esbuild");
const routes = fs
  .readdirSync("src/pages/insights")
  .filter((n) => n.endsWith(".tsx"))
  .map((name, i) => ({
    name,
    id: "P" + i,
    route: fs
      .readFileSync("src/pages/insights/" + name, "utf8")
      .match(/path="([^"]+)"/)[1],
  }));
const all = [
  { id: "HomePage", route: "", kind: "home", prefix: "" },
  { id: "Index", route: "/insights", kind: "index", prefix: "../" },
  ...routes.map((r) => ({ ...r, kind: "article", prefix: "../../" })),
];
const imports =
  "import React from 'react';import {renderToStaticMarkup} from 'react-dom/server';import {SiteLayout} from './src/components/SiteLayout';import {HomePage,HomeProvenance} from './src/pages/HomePage';import Index from './src/pages/InsightsPage';" +
  routes
    .map((r) => `import ${r.id} from './src/pages/insights/${r.name}';`)
    .join("");
fs.writeFileSync(
  ".render.tsx",
  imports +
    "export const pages=[" +
    all
      .map(
        (r) =>
          `{route:${JSON.stringify(r.route)},html:renderToStaticMarkup(<SiteLayout prefix="${r.prefix}" kind="${r.kind}" ${r.kind === "home" ? "provenance={<HomeProvenance/>}" : ""}><${r.id}/></SiteLayout>)}`,
      )
      .join(",") +
    "];",
);
buildSync({
  entryPoints: [".render.tsx"],
  outfile: ".render.cjs",
  bundle: true,
  platform: "node",
  format: "cjs",
  jsx: "automatic",
});
const { pages } = require("./.render.cjs");
const escape = (s) =>
  s.replaceAll("&", "&amp;").replaceAll('"', "&quot;").replaceAll("<", "&lt;");
for (const page of pages) {
  const r = all.find((r) => r.route === page.route);
  const source =
    r.kind === "home"
      ? ""
      : fs.readFileSync(
          r.kind === "index"
            ? "src/pages/InsightsPage.tsx"
            : "src/pages/insights/" + r.name,
          "utf8",
        );
  const meta = source.match(
    /<PageMeta\s+title="([^"]+)"\s+description="([^"]+)"/,
  );
  const body = page.html
    .replace(
      /href="\/insights\/([^"]+)"/g,
      (_, slug) => `href="${slug}/index.html"`,
    )
    .replace(
      /src="\/insights\/([^"]+)"/g,
      (_, name) => `src="${r.prefix}images/${name}"`,
    );
  const html =
    '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>' +
    escape(meta ? meta[1] + " | MOSAIC" : "MOSAIC — review draft v0.6") +
    "</title>" +
    (meta
      ? '<meta name="description" content="' + escape(meta[2]) + '">'
      : "") +
    '<link rel="stylesheet" href="' +
    r.prefix +
    'theme.css"></head><body>' +
    body +
    "</body></html>";
  fs.mkdirSync("site" + r.route, { recursive: true });
  fs.writeFileSync("site" + r.route + "/index.html", html);
}
fs.cpSync("public/insights", "site/images", { recursive: true });
fs.copyFileSync("src/styles/index.css", "site/theme.css");
fs.rmSync(".render.tsx");
fs.rmSync(".render.cjs");
const manifest = {};
function walk(dir) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const f = path.join(dir, e.name);
    if (e.isDirectory()) walk(f);
    else
      manifest[f] = createHash("sha256")
        .update(fs.readFileSync(f))
        .digest("hex");
  }
}
walk("site");
walk("src");
fs.writeFileSync(
  "output-manifest.json",
  JSON.stringify(manifest, null, 2) + "\n",
);
console.log(
  "Built eight static pages from shared React components; no client JavaScript.",
);
