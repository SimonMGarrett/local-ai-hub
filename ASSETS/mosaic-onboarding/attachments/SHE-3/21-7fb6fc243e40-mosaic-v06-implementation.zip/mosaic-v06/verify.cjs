const { chromium } = require("playwright");
const fs = require("fs"),
  path = require("path"),
  assert = require("assert"),
  crypto = require("crypto");
const executablePath =
  "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge";
const norm = (s) => s.replace(/\s+/g, " ").trim();
(async () => {
  const browser = await chromium.launch({ executablePath, headless: true });
  const page = await browser.newPage();
  fs.mkdirSync("verification", { recursive: true });
  const slugs = fs
    .readdirSync("site/insights")
    .filter((x) => fs.statSync("site/insights/" + x).isDirectory());
  const routes = ["", "insights", ...slugs.map((s) => "insights/" + s)];
  const layouts = [],
    parity = [],
    states = [];
  const open = async (route) =>
    page.goto("file://" + path.resolve("site", route, "index.html"));
  for (const width of [1440, 390, 768, 720]) {
    await page.setViewportSize({ width, height: 1000 });
    for (const route of routes) {
      await open(route);
      await page.evaluate(async () => {
        for (const i of document.images) {
          i.loading = "eager";
          await i.decode();
        }
      });
      const result = await page.evaluate(() => ({
        width: innerWidth,
        scrollWidth: document.documentElement.scrollWidth,
        h1: document.querySelectorAll("h1").length,
        images: [...document.images].map((i) => ({
          alt: i.alt,
          loaded: i.naturalWidth > 0,
        })),
        nestedControls: document.querySelectorAll("a a,a button").length,
      }));
      assert.equal(result.width, result.scrollWidth, route);
      assert.equal(result.h1, 1);
      assert(result.images.every((i) => i.loaded && i.alt));
      assert.equal(result.nestedControls, 0);
      const links = await page
        .locator("a")
        .evaluateAll((as) => as.map((a) => a.href));
      for (const url of links.filter((x) => x.startsWith("file:"))) {
        const u = new URL(url);
        assert(fs.existsSync(decodeURI(u.pathname)), url);
        if (u.hash) {
          const html = fs.readFileSync(decodeURI(u.pathname), "utf8");
          assert(html.includes('id="' + u.hash.slice(1) + '"'), url);
        }
      }
      layouts.push({
        route: route || "home",
        mode:
          width === 720
            ? "200% equivalent desktop reflow (1440/2 CSS pixels)"
            : "viewport",
        ...result,
      });
      if ([1440, 390].includes(width))
        await page.screenshot({
          path:
            "verification/" +
            (route.replaceAll("/", "-") || "home") +
            "-" +
            width +
            ".png",
          fullPage: true,
        });
    }
  }
  // Compare preserved semantic content, independent of layout and navigation changes.
  for (const route of routes) {
    await open(route);
    const selector = route.includes("insights/")
      ? ".insight-article"
      : route === "insights"
        ? "main"
        : "main";
    const current = norm(await page.locator(selector).textContent());
    const alts = await page
      .locator("img")
      .evaluateAll((xs) => xs.map((x) => x.alt));
    await page.goto(
      "file://" + path.resolve("../insights-v05/site", route, "index.html"),
    );
    let previous = norm(await page.locator(selector).textContent());
    if (route.endsWith("confidence-and-certainty"))
      previous = previous.replace(
        "Its stages help distinguish",
        "Its six forms of reasoning, which can be revisited as needed, help distinguish",
      );
    assert.equal(current, previous, "Copy parity " + route);
    assert.deepEqual(
      alts,
      await page.locator("img").evaluateAll((xs) => xs.map((x) => x.alt)),
    );
    parity.push({ route: route || "home", textAndAlt: true });
  }
  for (const f of fs.readdirSync("site/images"))
    assert.equal(
      crypto
        .createHash("sha256")
        .update(fs.readFileSync("site/images/" + f))
        .digest("hex"),
      crypto
        .createHash("sha256")
        .update(fs.readFileSync("../insights-v05/site/images/" + f))
        .digest("hex"),
    );
  // Keyboard checks on every page: skip, header order, all six cards/back links.
  for (const route of routes) {
    await open(route);
    await page.keyboard.press("Tab");
    assert.equal(await page.locator(":focus").innerText(), "Skip to content");
    await page.keyboard.press("Enter");
    assert.equal(await page.locator(":focus").getAttribute("id"), "main");
    await open(route);
    const labels = [];
    for (let i = 0; i < 4; i++) {
      await page.keyboard.press("Tab");
      labels.push(await page.locator(":focus").innerText());
    }
    assert.deepEqual(labels, [
      "Skip to content",
      "MOSAIC",
      "How it works",
      "Insights",
    ]);
  }
  for (const slug of slugs) {
    await open("insights");
    const card = page
      .getByRole("link", { name: /^Read article:/ })
      .filter({ has: page.locator("img") });
    const link = page.locator('a[href="' + slug + '/index.html"]');
    await link.focus();
    assert.equal(
      await link.evaluate((e) => getComputedStyle(e).outlineWidth),
      "3px",
    );
    await page.keyboard.press("Enter");
    await page.waitForURL("**/" + slug + "/index.html");
    await page.getByRole("link", { name: "← All insights" }).focus();
    await page.keyboard.press("Enter");
    await page.waitForURL("**/insights/index.html");
  }
  await open("");
  await page.getByRole("link", { name: "How it works", exact: true }).focus();
  await page.keyboard.press("Enter");
  assert.equal(new URL(page.url()).hash, "#how");
  await page.locator("summary").focus();
  await page.keyboard.press("Enter");
  assert(await page.locator("details").evaluate((e) => e.open));
  await page.keyboard.press("Space");
  assert(!(await page.locator("details").evaluate((e) => e.open)));
  await page.keyboard.press("Enter");
  assert(await page.locator("details").evaluate((e) => e.open));
  assert.equal(
    await page.evaluate(() => document.documentElement.scrollWidth),
    720,
  );
  // Read actual computed color combinations, including inherited backgrounds.
  async function color(selector, label) {
    const result = await page
      .locator(selector)
      .first()
      .evaluate((el) => {
        const s = getComputedStyle(el);
        let e = el,
          bg;
        while (e) {
          bg = getComputedStyle(e).backgroundColor;
          if (bg !== "rgba(0, 0, 0, 0)") break;
          e = e.parentElement;
        }
        return {
          fg: s.color,
          bg,
          outline: s.outlineColor,
          font: s.fontFamily,
          transition: s.transitionDuration,
        };
      });
    const rgb = (s) =>
      s
        .match(/[\d.]+/g)
        .slice(0, 3)
        .map(Number);
    const lum = (s) =>
      rgb(s)
        .map((x) => {
          x /= 255;
          return x <= 0.04045 ? x / 12.92 : ((x + 0.055) / 1.055) ** 2.4;
        })
        .reduce((a, x, i) => a + x * [0.2126, 0.7152, 0.0722][i], 0);
    const a = lum(result.fg),
      b = lum(result.bg);
    result.ratio = (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05);
    assert(result.ratio >= 4.5, label);
    states.push({ label, ...result });
  }
  await open("");
  await color("main>p:not(.eyebrow)", "body");
  await color(".caption", "caption");
  await color(".eyebrow", "eyebrow");
  await color(".action-link", "action default");
  await page.locator(".action-link").first().hover();
  await color(".action-link", "action hover");
  await color(".record p", "record tint");
  await open("insights");
  await color(".card-meta", "card metadata default");
  await color(".card-action", "Read article default");
  await page.locator(".insight-card").first().hover();
  await color(".card-action", "Read article hover");
  await color(".insight-card p", "card summary hover");
  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.screenshot({ path: "verification/card-hover.png" });
  await page.mouse.move(0, 0);
  await page.locator(".insight-card").first().focus();
  await color(".card-action", "Read article focus");
  await page.screenshot({ path: "verification/card-focus.png" });
  const focus = await page
    .locator(".insight-card")
    .first()
    .evaluate((e) => ({
      outline: getComputedStyle(e).outline,
      offset: getComputedStyle(e).outlineOffset,
      bounds: e.getBoundingClientRect().toJSON(),
    }));
  assert.equal(focus.offset, "5px");
  assert(focus.bounds.x >= 8 && focus.bounds.right <= 1440 - 8);
  await page.emulateMedia({ reducedMotion: "reduce" });
  assert(
    await page.evaluate(
      () => matchMedia("(prefers-reduced-motion: reduce)").matches,
    ),
  );
  assert(
    await page.locator("*").evaluateAll((es) =>
      es.every((e) => {
        const s = getComputedStyle(e);
        return (
          s.animationName === "none" &&
          s.transitionDuration === "0s" &&
          s.scrollBehavior === "auto"
        );
      }),
    ),
  );
  // Text-only 200% enlargement; snapshot all computed sizes before applying.
  for (const route of routes) {
    await page.setViewportSize({ width: 390, height: 1000 });
    await open(route);
    await page.evaluate(() => {
      const es = [...document.querySelectorAll("body *")];
      const sizes = es.map((e) => parseFloat(getComputedStyle(e).fontSize));
      es.forEach((e, i) => (e.style.fontSize = sizes[i] * 2 + "px"));
    });
    const result = await page.evaluate(() => ({
      width: innerWidth,
      scrollWidth: document.documentElement.scrollWidth,
    }));
    assert.equal(result.width, result.scrollWidth, "200% text " + route);
    layouts.push({
      route: route || "home",
      mode: "200% computed text enlargement at 390px",
      ...result,
    });
    await page.screenshot({
      path:
        "verification/text200-" +
        (route.replaceAll("/", "-") || "home") +
        ".png",
      fullPage: true,
    });
  }
  await open("insights");
  await page
    .locator(".insight-card img")
    .first()
    .evaluate((e) => (e.src = "missing-deliberate-test.jpg"));
  assert(
    await page
      .locator(".insight-card img")
      .first()
      .evaluate(
        (e) => e.getBoundingClientRect().height > 0 && e.alt.length > 0,
      ),
  );
  assert(await page.locator(".card-action").first().isVisible());
  fs.writeFileSync(
    "verification/results.json",
    JSON.stringify(
      {
        browser: await browser.version(),
        layouts,
        parity,
        imageByteParity: 6,
        states,
        focus,
        keyboard:
          "All page skip and header tab order; six card/back activations; home anchor; Enter/Space disclosure",
        reducedMotion: true,
        missingImage: "Aspect ratio, alt and action retained",
        limitations: [
          "Native browser zoom not exercised; equivalent CSS reflow and text-only scaling used",
          "Screen reader and non-Chromium browsers not tested",
          "Not a comprehensive accessibility audit",
        ],
      },
      null,
      2,
    ),
  );
  await browser.close();
  console.log(
    "40 layout cases, copy/image parity, routes, keyboard, computed contrasts, reduced motion passed.",
  );
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
