# MOSAIC Insights review draft v0.5
28 September 2026

Open **site/index.html** in a browser, then choose Insights. All seven Insights pages and their images work from local files, with no installation or server required. The accepted v0.4 homepage is preserved, with one navigation link added.

## Source and build
The original React/TypeScript page and shared component files are retained under src. One source of truth drives all cards, headings, images and article bodies. build.mjs renders these components to static HTML and compiles existing Tailwind CSS. No client JavaScript, analytics or submissions are included. Static page metadata is emitted from each original PageMeta declaration. The common page shell adds skip, home and back links. Article contact links point to the existing public contact page; no contact page was copied or message sent.

With dependencies installed, run npm run build. This run reused the supplied repository's installed node_modules read-only through a local symlink (excluded from the archive). A clean dependency install has not been tested. The original package and lockfile are recorded in source-originals; draft package versions are declared in package.json. verify.cjs requires Playwright and local Microsoft Edge; parity.cjs additionally requires public internet access.

source-manifest.json records exact source paths, SHA-256 hashes and archived locations. Files changed for build configuration have their originals in source-originals. Source repository was not edited. Generated output hashes are in output-manifest.json.

## Verification
See verification/results.json for 16 page/viewport checks: home, index and six articles at 1440×900 and 390×900. Each has zero horizontal overflow, one h1, resolved anchor targets and loaded images with alt text. Keyboard skip-to-main, six card activations, visible focus outline presence and six return links passed in headless Edge/Chromium. Full-page screenshots are included.

verification/live-parity.json records the live index text and six article bodies/headings matching after whitespace normalization, plus byte-identical six images. It is not a claim that all live metadata, global navigation or styles match. Live article body captures are saved separately. Existing article source, including credits, headings, lists, links and metadata, is preserved.

Homepage source equals the exact accepted attachment 5eb742e9-3da8-4529-b755-dae6b2a8e956; removing the added Insights link makes the generated homepage byte-identical to it.

## Limits and next review
Website Designer reviews consistency and original page structure; The Oracle reviews copied claims and provenance before Chief of Staff presents founder review. Existing source wording is not automatically an approved expansion of the MOSAIC baseline. The homepage and Insights retain their respective existing visual systems; broad unification was not attempted.

No screen-reader, Safari/Firefox, zoom, contrast audit or comprehensive accessibility test was run. External contact/credit destinations were not activated. Browser tests use file URLs, so hosted route configuration is unverified. No publication or participant testing.

The existing comprehension protocol is unchanged. Oracle should identify whether a future exposure includes Insights; that decision needs a new frozen exposure version, not an assumed result.

Final static resource check: every local href/src, including React-generated image preloads, resolves. Image preload paths were corrected after screenshots; visible content and CSS are unchanged. Visually inspected final home/index desktop and phone, More Data desktop and Prototypes phone screenshots. Other routes were measured and captured, not individually visually reviewed.
