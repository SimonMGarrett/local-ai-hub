const {chromium}=require('playwright'),fs=require('fs'),path=require('path'),crypto=require('crypto');
(async()=>{
 const browser=await chromium.launch({executablePath:'/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',headless:true});
 const page=await browser.newPage(); const results=[];
 const slugs=fs.readdirSync('site/insights').filter(x=>fs.statSync('site/insights/'+x).isDirectory());
 for(const slug of ['',...slugs]){
 const route='/insights'+(slug?'/'+slug:'');
 await page.goto('file://'+path.resolve('site'+route+'/index.html'));
 const selector=slug?'article.insight-article':'main section';
 const local=await page.locator(selector).innerText();
 const localHeading=await page.locator('h1').innerText();
 await page.goto('https://groundstoact.com'+route,{waitUntil:'networkidle'});
 const live=await page.locator(selector).innerText();
 const liveHeading=await page.locator('h1').innerText();
 fs.writeFileSync('verification/live-'+(slug||'index')+'.txt',live);
 results.push({route,status:'rendered',textMatches:local.replace(/\s+/g,' ').trim()===live.replace(/\s+/g,' ').trim(),headingMatches:localHeading===liveHeading});
 }
 for(const filename of fs.readdirSync('public/insights')){
 const response=await page.request.get('https://groundstoact.com/insights/'+filename);
 const bytes=await response.body(),hash=x=>crypto.createHash('sha256').update(x).digest('hex');
 results.push({image:filename,status:response.status(),sha256:hash(bytes),matches:hash(bytes)===hash(fs.readFileSync('public/insights/'+filename))});
 }
 fs.writeFileSync('verification/live-parity.json',JSON.stringify(results,null,2));
 await browser.close();console.log(JSON.stringify(results));
})().catch(e=>{console.error(e);process.exit(1)});
