import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {execFileSync} from 'node:child_process';
const require=createRequire(import.meta.url);
const {buildSync}=require('esbuild');
fs.mkdirSync('site/insights',{recursive:true});
const routes=fs.readdirSync('src/pages/insights').filter(x=>x.endsWith('.tsx')).map((name,i)=>({name,id:'P'+i,route:fs.readFileSync('src/pages/insights/'+name,'utf8').match(/path="([^"]+)"/)[1]}));
const all=[{id:'Index',route:'/insights'},...routes];
fs.writeFileSync('.render.tsx', "import React from 'react';import {renderToStaticMarkup} from 'react-dom/server';import {MemoryRouter} from 'react-router-dom';import Index from './src/pages/InsightsPage';"+routes.map(x=>"import "+x.id+" from './src/pages/insights/"+x.name+"';").join('')+"export const pages=["+all.map(x=>"{route:"+JSON.stringify(x.route)+",html:renderToStaticMarkup(<MemoryRouter><"+x.id+"/></MemoryRouter>)}").join(',')+"];");
buildSync({entryPoints:['.render.tsx'],outfile:'.render.cjs',bundle:true,platform:'node',format:'cjs',jsx:'automatic',nodePaths:[path.dirname(require.resolve('react/package.json'))+'/..']});
const {pages}=require('./.render.cjs');
execFileSync(process.execPath,[require.resolve('tailwindcss/lib/cli.js'),'-i','src/styles/index.css','-o','site/insights.css','--minify']);
const escape=s=>s.replaceAll('&','&amp;').replaceAll('"','&quot;').replaceAll('<','&lt;');
for(const page of pages){
 const index=page.route==='/insights', prefix=index?'../':'../../', back=index?'index.html':'../index.html';
 const source=fs.readFileSync(index?'src/pages/InsightsPage.tsx':'src/pages/insights/'+routes.find(x=>x.route===page.route).name,'utf8');
 const meta=source.match(/<PageMeta\s+title="([^"]+)"\s+description="([^"]+)"/);
 const body=page.html.replace(/href="\/insights\/([^"]+\.(?:jpg|webp))"/g,(_,name)=>'href="'+prefix+'images/'+name+'"').replace(/href="\/insights\/([^"]+)"/g,(_,slug)=>'href="'+slug+'/index.html"').replace(/src="\/insights\/([^"]+)"/g,(_,name)=>'src="'+prefix+'images/'+name+'"').replaceAll('href="/contact"','href="https://groundstoact.com/contact"');
 const html='<!doctype html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>'+escape(meta[1])+' | MOSAIC</title><meta name="description" content="'+escape(meta[2])+'"><link rel="stylesheet" href="'+prefix+'insights.css"><style>.skip{position:absolute;left:1rem;top:-100px;background:white;padding:12px;z-index:2}.skip:focus{top:1rem}nav a{text-decoration:underline;text-underline-offset:4px}nav a:first-child{font-weight:700}footer{border-top:1px solid #e2ded3}</style></head><body class="bg-paper text-ink"><a class="skip" href="#main">Skip to content</a><header class="container py-6"><nav aria-label="Main navigation" class="flex flex-wrap gap-6"><a href="'+prefix+'index.html">MOSAIC</a><a href="'+back+'"'+(index?' aria-current="page"':'')+'>'+(index?'Insights':'← All insights')+'</a></nav></header><main id="main" tabindex="-1">'+body+'</main><footer class="container py-6 text-sm text-muted">Review draft v0.5 · Insights source captured 28 September 2026. <a href="'+back+'">All insights</a> · <a href="'+prefix+'index.html">MOSAIC home</a></footer></body></html>';
 const folder='site'+page.route;fs.mkdirSync(folder,{recursive:true});fs.writeFileSync(folder+'/index.html',html);
}
fs.cpSync('public/insights','site/images',{recursive:true});
const home=fs.readFileSync('accepted-v04.html','utf8');
if(!home.includes('</nav>'))throw Error('Homepage nav missing');
fs.writeFileSync('site/index.html',home.replace('</nav>','<a href="insights/index.html">Insights</a></nav>'));
fs.rmSync('.render.cjs');fs.rmSync('.render.tsx');
console.log('Built homepage, Insights index and six articles.');
