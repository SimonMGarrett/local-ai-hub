import { InsightArticleImage } from "../../components/InsightArticleImage";
import { PageMeta } from "../../components/PageMeta";
import { PrimaryButton } from "../../components/PrimaryButton";
import { SectionHeading } from "../../components/SectionHeading";

export default function ConfidenceAndCertaintyPage() {
  return (
    <>
      <PageMeta
        title="The difference between confidence and certainty"
        description="Confidence can support a decision without pretending that uncertainty has disappeared."
        path="/insights/confidence-and-certainty"
      />
      <section className="container py-14">
        <SectionHeading
          eyebrow="Decision quality"
          title="The difference between confidence and certainty"
          level="h1"
        >
          A decision can be well-grounded without claiming more than the evidence can support.
        </SectionHeading>

        <InsightArticleImage
          alt="A yellow direction sign standing at a snowy rural crossroads"
          photographer="Earl McKenzie"
          photoUrl="https://unsplash.com/photos/yellow-directional-sign-at-a-rural-crossroads-3csm4E8wGoE"
          src="/insights/confidence-certainty.jpg"
        />

        <article className="insight-article mt-10 max-w-3xl text-lg leading-8 text-muted">
          <p>
            <strong>Confidence and certainty</strong> are often used as if they mean the same thing.
            In everyday work, they can feel close: both suggest that someone is prepared to stand
            behind a conclusion. But they do different jobs.{" "}
            <strong>Certainty suggests that meaningful doubt has been removed.</strong>{" "}
            <strong>Confidence is a judgement</strong> about whether the available evidence,
            reasoning, and context are sufficient to take a particular next step.
          </p>
          <p className="mt-6">
            That distinction matters because most decisions are made before every question has been
            answered. A service team may need to change a process while feedback is still uneven. A
            public organisation may need to act on an emerging risk before its full scale is known.
            A business may have to choose between two credible options whose future outcomes cannot
            be proven in advance. <strong>Waiting for certainty can be another choice</strong>, with
            its own costs and risks.
          </p>
          <p className="mt-6">
            <strong>Useful confidence does not come from sounding definite.</strong> It comes from
            being able to say what has been observed, how dependable those observations are, what
            interpretation is being made, and what might still change the picture. A team can be
            confident that a small, reversible intervention is justified while remaining uncertain
            about its long-term effect. It can be confident in the direction of travel without
            claiming an exact forecast.
          </p>
          <p className="mt-6">
            This is where <strong>false precision</strong> can be particularly unhelpful. A score,
            percentage, or neat label may make uncertainty look settled when it is not. Quantitative
            measures can be valuable, but they need their provenance and limits alongside them:
            which data was included, which assumptions shaped the calculation, and whether the
            number describes a stable pattern or a partial signal. The same is true of professional
            judgement. It can be well-informed without becoming infallible.
          </p>
          <p className="mt-6">
            MOSAIC treats <strong>uncertainty as something to make visible</strong>, not a defect to
            conceal before action is allowed. Its stages help distinguish observations from the
            structure around them, analysis from interpretation, and a choice from the later
            evidence that may challenge it. This does not produce a formula for certainty. It makes
            the rationale for confidence inspectable: why this action, why now, and under what
            conditions should it be reconsidered?
          </p>
          <p className="mt-6">
            The right level of confidence depends on{" "}
            <strong>
              the consequence of being wrong, the reversibility of the decision, and the
              opportunities to learn after acting
            </strong>
            . If you are trying to make those judgements clearer in a particular setting, contact
            Simon. He can help explore how evidence, uncertainty, and review can support action
            without overstating what is known.
          </p>
          <div className="mt-8">
            <PrimaryButton to="/contact">Contact Simon</PrimaryButton>
          </div>
        </article>
      </section>
    </>
  );
}
