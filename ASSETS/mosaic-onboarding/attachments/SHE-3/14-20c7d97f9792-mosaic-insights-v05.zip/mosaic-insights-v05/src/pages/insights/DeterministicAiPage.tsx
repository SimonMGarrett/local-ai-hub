import { InsightArticleImage } from "../../components/InsightArticleImage";
import { PageMeta } from "../../components/PageMeta";
import { PrimaryButton } from "../../components/PrimaryButton";
import { SectionHeading } from "../../components/SectionHeading";

export default function DeterministicAiPage() {
  return (
    <>
      <PageMeta
        title="What should remain deterministic in an AI system?"
        description="Some decisions in an AI system need rules, auditability, and explicit ownership before model judgement enters."
        path="/insights/deterministic-ai"
      />
      <section className="container py-14">
        <SectionHeading
          eyebrow="AI systems"
          title="What should remain deterministic in an AI system?"
          level="h1"
        >
          Some decisions need rules, auditability, and explicit ownership before model judgement
          enters.
        </SectionHeading>

        <InsightArticleImage
          alt="A circle of domino-like blocks with several fallen inward"
          src="/insights/deterministic-ai.webp"
        />

        <article className="insight-article mt-10 max-w-3xl text-lg leading-8 text-muted">
          <p>
            AI systems are often discussed as if intelligence should be spread evenly through every
            part of a process. In practice,{" "}
            <strong>a useful system is usually more selective</strong>. Some work benefits from
            model judgement: finding patterns in large collections of material, drafting a summary,
            or suggesting questions that a person may want to explore. Other parts need to behave
            the same way every time.
          </p>
          <p className="mt-6">
            A deterministic part of a system has an <strong>understandable contract</strong>: given
            the same input, it applies the same rule and produces the same result. That can be
            valuable when the system is handling permissions, thresholds, required checks, money,
            safety controls, record retention, or a decision that needs a clear owner. It gives
            people something stable to inspect when a result is challenged or a process needs to be
            repeated.
          </p>
          <p className="mt-6">
            This is not a claim that rules are always objective or that models are inherently
            untrustworthy. <strong>Rules still embed choices</strong>: who can approve an exception,
            what counts as sufficient evidence, and when a case must be escalated. The difference is
            that these choices can be made visible, discussed, tested, and changed deliberately. A
            model can support that work, but it should not quietly replace it.
          </p>
          <p className="mt-6">
            One practical question is not simply, “Can an AI do this?” It is,{" "}
            <strong>“What must be predictable here, and why?”</strong> The answer will differ
            between a low-stakes internal tool and a system that affects a customer, employee,
            patient, or public service. It may be sensible for a model to prioritise a queue, while
            the decision to deny access, release a payment, or close an investigation remains
            governed by explicit rules and human responsibility.
          </p>
          <p className="mt-6">
            <strong>The hand-off between these modes matters</strong> as much as the modes
            themselves. A system can make it clear which information was supplied to a model, which
            rule was applied after it responded, and when a person was asked to intervene. This
            creates a more useful record than a single opaque answer. It also makes exceptions
            visible: perhaps a recommendation was overridden, a threshold was unsuitable for a
            particular case, or the available evidence was too thin to support automation. Those
            moments are not necessarily failures. They can reveal where the process needs more care.
          </p>
          <p className="mt-6">
            A strong design often <strong>combines both modes</strong>. Deterministic components can
            preserve boundaries, provenance, and safeguards; AI can help people work with ambiguity
            inside those boundaries. The important work is deciding where that line belongs,
            documenting it, and reviewing it as the system and its context change.
          </p>
          <section className="mt-10 rounded-lg border border-gold bg-gold/10 p-6 text-ink">
            <h2 className="text-2xl font-semibold">Making the boundary useful</h2>
            <p className="mt-4 leading-7 text-muted">
              If you are working out which parts of an AI-enabled process should be governed by
              rules, model judgement, or human review, Simon can help frame the questions and make
              the resulting decision process clearer. The right arrangement depends on the decision,
              the evidence, and the consequences of being wrong.
            </p>
            <PrimaryButton className="mt-6" to="/contact">
              Contact Simon
            </PrimaryButton>
          </section>
        </article>
      </section>
    </>
  );
}
