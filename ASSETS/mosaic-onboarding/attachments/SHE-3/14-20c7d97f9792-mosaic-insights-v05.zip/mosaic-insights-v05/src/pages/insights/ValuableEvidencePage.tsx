import { InsightArticleImage } from "../../components/InsightArticleImage";
import { PageMeta } from "../../components/PageMeta";
import { PrimaryButton } from "../../components/PrimaryButton";
import { SectionHeading } from "../../components/SectionHeading";

export default function ValuableEvidencePage() {
  return (
    <>
      <PageMeta
        title="The most valuable evidence may be the evidence you do not yet have"
        description="Useful investigation begins by asking what missing evidence would materially change the decision."
        path="/insights/valuable-evidence"
      />
      <section className="container py-14">
        <SectionHeading
          eyebrow="Investigation"
          title="The most valuable evidence may be the evidence you do not yet have"
          level="h1"
        >
          Useful investigation starts with what would change the decision.
        </SectionHeading>

        <InsightArticleImage
          alt="A woman whispering to another woman outdoors"
          src="/insights/valuable-evidence.webp"
        />

        <article className="insight-article mt-10 max-w-3xl text-lg leading-8 text-muted">
          <p>
            When a decision feels uncertain, the natural response is often to ask for{" "}
            <strong>more evidence</strong>. That can be sensible, but it is not yet a plan. Teams
            can spend considerable time gathering material that adds colour, reassurance, or detail
            without changing what they are prepared to do. The more useful question is often
            narrower:{" "}
            <strong>what do we need to know that could genuinely alter this choice?</strong>
          </p>
          <p className="mt-6">
            This is not a call to reduce every situation to a single decisive number. Important
            choices may involve people, trade-offs, local knowledge, and consequences that cannot be
            settled by a metric alone. It is a way to <strong>give inquiry a purpose</strong>. If a
            new observation would not affect the timing, direction, safeguards, or ownership of an
            action, it may be worth recognising that before investing heavily in finding it.
          </p>
          <p className="mt-6">
            <strong>Decision-sufficient evidence</strong> is evidence that allows a group to act
            responsibly for the decision in front of it. It is different from{" "}
            <strong>complete evidence</strong>. Completeness is often unavailable, particularly when
            conditions are changing or the decision is time-bound. Sufficiency asks whether the
            important uncertainties are visible, whether credible alternatives have been considered,
            and whether the remaining risk can be accepted or managed. The answer will rightly
            differ between a routine operational adjustment and a high-consequence commitment.
          </p>

          <section className="mt-10 rounded-lg border border-line bg-white p-6">
            <h2 className="text-2xl font-semibold leading-tight text-ink">
              Start with the decision, then target the inquiry
            </h2>
            <p className="mt-4">
              A practical conversation might begin by <strong>naming the decision</strong> that is
              actually being made, the options still open, and the assumptions that currently
              separate them. From there, a team can ask a few useful questions:
            </p>
            <ul className="mt-5 list-disc space-y-2 pl-6">
              <li>
                What would make us choose a different option, delay action, or add a safeguard?
              </li>
              <li>Which uncertainty has the greatest consequence if our current view is wrong?</li>
              <li>What source, observation, or small test could most usefully clarify it?</li>
              <li>What can be recorded as uncertain and reviewed after action instead?</li>
            </ul>
          </section>

          <p className="mt-8">
            The answers may point to a missing dataset, but just as often they point elsewhere: a
            conversation with people closest to the work, a check on how a measure was defined, a
            comparison with a similar case, or a limited trial. <strong>Targeted inquiry</strong>{" "}
            makes those choices explicit. It can prevent the apparent authority of a large evidence
            collection from obscuring a small but consequential gap.
          </p>
          <p className="mt-6">
            MOSAIC helps make this line of reasoning visible by connecting observations, their
            context, the interpretation they support, and the choice that follows. It does not
            promise a universal threshold for “enough” evidence.{" "}
            <strong>That judgement belongs to the people accountable for the decision</strong> and
            the setting in which they are working.
          </p>

          <div className="mt-10 border-t border-line pt-8">
            <h2 className="text-2xl font-semibold leading-tight text-ink">
              Explore the evidence that matters in your context
            </h2>
            <p className="mt-4">
              If you are working through a consequential decision and want help framing a focused
              inquiry, identifying the uncertainties that matter, or making the rationale easier to
              revisit, contact Simon to discuss your situation.
            </p>
            <PrimaryButton className="mt-6" to="/contact" umamiEvent="insight-contact-click">
              Contact Simon
            </PrimaryButton>
          </div>
        </article>
      </section>
    </>
  );
}
