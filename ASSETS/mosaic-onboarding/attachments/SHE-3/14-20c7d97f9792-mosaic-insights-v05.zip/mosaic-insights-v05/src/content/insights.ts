export const insightCards = [
  {
    title: "Why more data does not automatically produce a better decision",
    summary:
      "Evidence needs structure, relevance, and interpretation before it can support action.",
    topic: "Decision quality",
    time: "5 min read",
    path: "/insights/more-data",
    image: "/insights/more-data.jpg",
    imageAlt: "Hands reviewing printed financial charts beside a calculator and phone",
  },
  {
    title: "The danger of the first plausible explanation",
    summary: "A reasonable story can still be wrong if alternatives are never tested.",
    topic: "Reasoning",
    time: "4 min read",
    path: "/insights/first-plausible-explanation",
    image: "/insights/first-explanation.jpg",
    imageAlt: "A Rubik's cube beside a laptop on a working desk",
  },
  {
    title: "What should remain deterministic in an AI system?",
    summary:
      "Some decisions need rules, auditability, and explicit ownership before model judgement enters.",
    topic: "AI systems",
    time: "6 min read",
    path: "/insights/deterministic-ai",
    image: "/insights/deterministic-ai.webp",
    imageAlt: "A circle of domino-like blocks with several fallen inward",
  },
  {
    title: "The difference between confidence and certainty",
    summary: "Confidence can guide action while still leaving room for revision.",
    topic: "Uncertainty",
    time: "4 min read",
    path: "/insights/confidence-and-certainty",
    image: "/insights/confidence-certainty.jpg",
    imageAlt: "A yellow direction sign standing at a snowy rural crossroads",
  },
  {
    title: "Prototypes, proofs of concept, and enterprise software",
    summary:
      "A prototype demonstrates possibility; production software needs governance and operational clarity.",
    topic: "Product",
    time: "7 min read",
    path: "/insights/prototypes-and-enterprise-software",
    image: "/insights/prototypes.webp",
    imageAlt: "An architectural rendering of a railway station and surrounding streets",
  },
  {
    title: "The most valuable evidence may be the evidence you do not yet have",
    summary: "Useful investigation starts with what would change the decision.",
    topic: "Investigation",
    time: "5 min read",
    path: "/insights/valuable-evidence",
    image: "/insights/valuable-evidence.webp",
    imageAlt: "A woman whispering to another woman outdoors",
  },
];
