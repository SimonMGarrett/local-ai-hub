type Props = {
  eyebrow?: string;
  title: string;
  children?: React.ReactNode;
  level?: "h1" | "h2";
};

export function SectionHeading({ eyebrow, title, children, level = "h2" }: Props) {
  const HeadingTag = level;

  return (
    <div className="max-w-3xl">
      {eyebrow ? <p className="eyebrow">{eyebrow}</p> : null}
      <HeadingTag className="mt-3 text-3xl font-semibold leading-tight text-ink sm:text-4xl">
        {title}
      </HeadingTag>
      {children ? <div className="mt-4 text-lg leading-8 text-muted">{children}</div> : null}
    </div>
  );
}
