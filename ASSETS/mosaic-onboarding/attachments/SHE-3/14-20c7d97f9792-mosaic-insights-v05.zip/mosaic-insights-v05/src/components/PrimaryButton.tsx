import { Link } from "react-router-dom";

type ButtonProps = {
  children: React.ReactNode;
  to?: string;
  type?: "button" | "submit" | "reset";
  onClick?: () => void;
  umamiEvent?: string;
  variant?: "default" | "inverse";
  className?: string;
};

const variants = {
  default: "bg-accent text-white hover:bg-[#0b1d3d]",
  inverse: "bg-white text-accent hover:bg-[#f4f0e7]",
};

export function PrimaryButton({
  children,
  to,
  type = "button",
  onClick,
  umamiEvent,
  variant = "default",
  className = "",
}: ButtonProps) {
  const classes = `inline-flex min-h-11 items-center justify-center rounded-md px-5 py-2.5 text-sm font-semibold transition ${variants[variant]} ${className}`;
  if (to)
    return (
      <Link className={classes} to={to} data-umami-event={umamiEvent}>
        {children}
      </Link>
    );
  return (
    <button className={classes} type={type} onClick={onClick} data-umami-event={umamiEvent}>
      {children}
    </button>
  );
}
