type Props = {
  src: string;
  alt: string;
  photographer?: string;
  photoUrl?: string;
};

export function InsightArticleImage({ src, alt, photographer, photoUrl }: Props) {
  return (
    <figure className="mt-10 max-w-4xl">
      <img
        alt={alt}
        className="aspect-[16/9] w-full rounded-lg border border-line object-cover shadow-soft"
        decoding="async"
        height="900"
        src={src}
        width="1600"
      />
      {photographer && photoUrl ? (
        <figcaption className="mt-2 text-xs text-muted">
          Photo by{" "}
          <a className="underline hover:text-ink" href={photoUrl} rel="noreferrer" target="_blank">
            {photographer} on Unsplash
          </a>
        </figcaption>
      ) : null}
    </figure>
  );
}
