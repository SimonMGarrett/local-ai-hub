import { Link } from "react-router-dom";

export function InsightCard({
  title,
  summary,
  topic,
  time,
  path,
  image,
  imageAlt,
}: {
  title: string;
  summary: string;
  topic: string;
  time: string;
  path: string;
  image: string;
  imageAlt: string;
}) {
  return (
    <Link aria-label={`Read article: ${title}`} className="group block h-full rounded-lg" to={path}>
      <article className="panel flex h-full flex-col overflow-hidden transition group-hover:border-gold group-hover:shadow-lg">
        <img
          alt={imageAlt}
          className="aspect-[16/9] w-full border-b border-line object-cover"
          decoding="async"
          height="360"
          loading="lazy"
          src={image}
          width="640"
        />
        <div className="flex flex-1 flex-col p-6">
          <div className="flex flex-wrap gap-2 text-xs font-semibold uppercase tracking-[0.12em] text-accent">
            <span>{topic}</span>
            <span aria-hidden="true">/</span>
            <span>{time}</span>
          </div>
          <h2 className="mt-4 text-xl font-semibold">{title}</h2>
          <p className="mt-3 leading-7 text-muted">{summary}</p>
          <div className="mt-auto pt-5">
            <span
              aria-hidden="true"
              className="inline-flex rounded-full bg-gold/10 px-3 py-1 text-sm font-semibold transition group-hover:bg-gold/20"
            >
              Read article
            </span>
          </div>
        </div>
      </article>
    </Link>
  );
}
