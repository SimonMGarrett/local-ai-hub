const {chromium}=require('playwright');
const fs=require('fs'),path=require('path'),assert=require('assert');
(async()=>{
const browser=await chromium.launch({executablePath:'/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',headless:true});
const page=await browser.newPage();fs.mkdirSync('verification',{recursive:true});
const slugs=fs.readdirSync('site/insights').filter(x=>fs.statSync('site/insights/'+x).isDirectory());
const results=[];
for(const width of [1440,390]){
 await page.setViewportSize({width,height:900});
 for(const route of ['', 'insights',...slugs.map(x=>'insights/'+x)]){
 const file=path.resolve('site',route,'index.html');await page.goto('file://'+file);await page.locator('footer').scrollIntoViewIfNeeded();await page.evaluate(()=>window.scrollTo(0,0));
 await page.waitForFunction(()=>[...document.images].every(i=>i.complete));
 const result=await page.evaluate(()=>({title:document.title,width:innerWidth,scrollWidth:document.documentElement.scrollWidth,images:[...document.images].map(i=>({src:i.getAttribute('src'),loaded:i.naturalWidth>0,alt:i.alt})),h1:document.querySelectorAll('h1').length,brokenLinks:[...document.querySelectorAll('a[href^="#"]')].filter(a=>!document.getElementById(a.hash.slice(1))).map(a=>a.hash)}));
 assert.equal(result.width,result.scrollWidth);assert.equal(result.h1,1);assert(result.images.every(i=>i.loaded&&i.alt));assert.equal(result.brokenLinks.length,0);
 results.push({route:route||'home',...result});
 await page.screenshot({path:'verification/'+(route.replaceAll('/','-')||'home')+'-'+width+'.png',fullPage:true});
 }
}
await page.goto('file://'+path.resolve('site/insights/index.html'));
await page.keyboard.press('Tab');assert.equal(await page.locator(':focus').innerText(),'Skip to content');
await page.keyboard.press('Enter');assert.equal(await page.locator(':focus').getAttribute('id'),'main');
for(const slug of slugs){
 await page.goto('file://'+path.resolve('site/insights/index.html'));
 const card=page.locator('a[href="'+slug+'/index.html"]');await card.focus();
 assert.notEqual(await card.evaluate(e=>getComputedStyle(e).outlineStyle),'none');
 await page.keyboard.press('Enter');await page.waitForURL('**/'+slug+'/index.html');
 await page.getByRole('link',{name:'← All insights'}).focus();await page.keyboard.press('Enter');await page.waitForURL('**/insights/index.html');
}
fs.writeFileSync('verification/results.json',JSON.stringify({results,keyboard:'Skip link, six card activations, focus outline presence, six back links passed'},null,2));
await browser.close();console.log('16 page/viewport checks; image, heading, overflow, internal anchor and keyboard checks passed.');
})().catch(e=>{console.error(e);process.exit(1)});
