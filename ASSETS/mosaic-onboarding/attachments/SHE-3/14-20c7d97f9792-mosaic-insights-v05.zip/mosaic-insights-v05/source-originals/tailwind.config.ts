import type { Config } from "tailwindcss";

export default {
  darkMode: "class",
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  safelist: ["bg-gold", "text-gold", "border-gold", "bg-cyan", "text-cyan", "border-cyan"],
  theme: {
    extend: {
      colors: {
        paper: "#fbfaf7",
        ink: "#20201d",
        muted: "#66645e",
        line: "#e2ded3",
        accent: "#102a56",
        amber: "rgb(var(--color-gold-rgb) / <alpha-value>)",
        gold: "rgb(var(--color-gold-rgb) / <alpha-value>)",
        cyan: "rgb(var(--color-cyan-rgb) / <alpha-value>)",
      },
      boxShadow: {
        soft: "0 18px 45px rgba(32, 32, 29, 0.08)",
      },
      fontFamily: {
        sans: [
          "Inter",
          "ui-sans-serif",
          "system-ui",
          "-apple-system",
          "BlinkMacSystemFont",
          "Segoe UI",
          "sans-serif",
        ],
      },
    },
  },
  plugins: [],
} satisfies Config;
